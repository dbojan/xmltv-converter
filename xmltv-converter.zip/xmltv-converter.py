

#2023-10-09-1

import sqlite3
import os
import xml.etree.ElementTree as ET

import sys

#settings
int_order=201
'''
1=channel_id
2=display_name
12=channel_id (display_name)
21=display_name (channel_id)
102=channel_id + (display_name if different from channel_id)
201=display_name + (channel_id if different from display_name)

'''



try:
	st_input_xml=sys.argv[1]
except:
	print('Please pass XML file name')
	exit()


if not os.path.isfile(st_input_xml):
	print('exiting, no file:', st_input_xml)
	exit()

print('Input xml file:', st_input_xml)





#needed func for insert into db at start, check available in hash folder
def fn_sql_command_do(sql_update_query, multilist):
	#sql_update_query = "UPDATE items SET db_xml_item_exists_in_hash_dir = ? WHERE db_id = ?"
	#data = (st_new_value,st_condition_value)
	#print(multilist[0])
	try:
		if len(multilist) == 0:
			cursor.execute(sql_update_query)
		else:
			cursor.executemany(sql_update_query,multilist)
		cursor.commit()
	except sqlite3.Error as error:
		print("\n***Warning *** : Failed to insert Python variable into sqlite table\n", error)
		input()



#1. CREATE DB IN MEMORY
def fn_create_db_in_memory():
	global st_db_in_memory
	st_db_in_memory = ':memory:'
	global cursor #use global version of cursor variable instead of local version
	cursor = sqlite3.connect(st_db_in_memory)

	sql_update_query = '''CREATE TABLE items
			(db_id integer primary key AUTOINCREMENT not null ,
			db_channel text,
			db_title text,					
			db_start text,
			db_stop text,
			db_desc text,
			db_channel_original text,
			db_display_name text,			
			UNIQUE(db_id)
			)'''
	fn_sql_command_do(sql_update_query, [])#no second argument, so we send just empty list


def fn_save_db_to_hdd(st_input_xml_save_db_to_hdd):
	global cursor
	cursor.commit()
	st_db_on_hdd=st_input_xml_save_db_to_hdd+'-sqlite.db'
	print ('Saving', st_input_xml_save_db_to_hdd , 'as sqlite database to hdd ...' )

	if os.path.isfile(st_db_on_hdd):
		os.remove(st_db_on_hdd)

	c2 = sqlite3.connect(st_db_on_hdd)
	with c2:
		for line in cursor.iterdump():
			if line not in ('BEGIN;', 'COMMIT;'): # let python handle the transactions
				c2.execute(line)
	c2.commit()
	c2.close()
	
	if os.path.isfile(st_db_on_hdd):
		print('Saved as', st_db_on_hdd)
		
		
		
		
		
		
		

def fn_parse_xml(st_input_xml):
	print ('Loading xml file, finding root element of xml ...')
	global cursor
	global root
	root = ET.parse(st_input_xml).getroot()#tv
	#print (root.tag)
	#root = etree.parse(st_input_xml) #for lxml


	#CHANNEL NAME = DISPLAYID

	if root.find('channel'):#use .find for 1 element, or .find all to find all elements
		st_main_element = 'channel'

	#add id and display name to dict
	dic_id_display_name = {}
	for single_element in root.findall(st_main_element):#st_main_element is 'programme' element
		st_id = single_element.get('id')
		st_display_name = single_element.find('display-name')

		if st_id is None:
			pass
		else:
			st_id =  st_id.strip()


		if st_display_name is None:
			pass
		else:
			st_display_name = st_display_name.text
			st_display_name = st_display_name.strip()
	
		if st_id is not None and st_display_name is not None:
			dic_id_display_name[st_id] = st_display_name



	#PROGRAMME
	if root.find('programme'):#use .find for 1 element, or .find all to find all elements
		st_main_element = 'programme'
	else:
		print('Exiting, cannot find programme element in', st_input_xml)
		return

	multilist = []
	single_list = []
	
	#go through 'root.programme' elements in xml:
	for single_element in root.findall(st_main_element):#st_main_element is 'programme' element
		st_channel = single_element.get('channel')
		
		
		if st_channel is None:
			print('Warning missing data in xml file:',st_input_xml, 'missing programme channel' )
		else:
			st_channel = st_channel.strip()
			
		st_channel_original = st_channel #for db
		
		
		if st_channel in dic_id_display_name:
			st_display_name = dic_id_display_name[st_channel]
		else:
			st_display_name = None # for later
	
		#combine if st_channel != display-name,    and if it has another display name
		'''
		if st_channel is not None   and  st_channel in dic_id_display_name:
			if st_channel != dic_id_display_name[st_channel]:
				#set original display-name, for db
				st_display_name = dic_id_display_name[st_channel]
				#combine displayname and channel name, to be main name
				st_channel = dic_id_display_name[st_channel] + ' ('+st_channel+')'
		'''
		
		
		#for comparison
		if st_channel is None:
			st_channel = ""
		if st_display_name is None:
			st_display_name = ""
		
		if int_order == 1:
			pass
		elif int_order == 2:
			st_channel = st_display_name				
		if int_order == 12:
			st_channel = st_channel + ' (' + st_display_name +')'
		elif int_order == 21:
			st_channel = st_display_name + ' (' +  st_channel +')'

		#combine displayname and channel name, to be main name, if different
		elif int_order == 201:
			if st_channel != st_display_name:
				st_channel = st_display_name + ' (' + st_channel +')'

		elif int_order == 102:
			if st_channel != st_display_name:
				st_channel = st_channel + ' (' +  st_display_name +')'

		
			
		st_start = single_element.get('start')
		st_stop = single_element.get('stop')


		st_title = single_element.find('title')
		if st_title is None:
			pass
		else:
			st_title =  st_title.text

		st_desc = single_element.find('desc')
		if st_desc is None:
			pass
		else:
			st_desc =  st_desc.text
		
		single_list = [st_channel, st_title, st_start, st_stop, st_desc, st_channel_original, st_display_name  ]
		multilist.append(single_list)
		
	sql_update_query = 'INSERT OR IGNORE INTO items (db_channel, db_title, db_start, db_stop, db_desc, db_channel_original, db_display_name)             VALUES  (?,?,?,?,?,?,?)'
	if multilist !=[]: #if not empty
		#print(multilist);input()
		fn_sql_command_do(sql_update_query, multilist)
		


		
		
		
		
#st_input_xml = 'tv1.xml'
fn_create_db_in_memory()
fn_parse_xml(st_input_xml)
fn_save_db_to_hdd(st_input_xml)